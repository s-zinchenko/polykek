const bird = document.querySelector(".bird");
const feather = document.querySelector(".feather2");
const btn = document.querySelector(".main__btn");

feather.style.animation = "flap 1s infinite";

const birdAnimationStop = () => {
  bird.classList.toggle('bird-fly');
};

btn.addEventListener("click", birdAnimationStop);
